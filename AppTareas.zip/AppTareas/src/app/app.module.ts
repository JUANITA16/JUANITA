import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { provideFirebaseApp, getApp, initializeApp } from '@angular/fire/app';
import { getFirestore, provideFirestore } from '@angular/fire/firestore';

import { AppComponent } from './app.component';
import { SharedService } from './services/shared.service';
const firebaseConfig = {
  apiKey: "AIzaSyCfZjll4L6tFgzwHDlLJobE-_1JhLoXVHU",
  authDomain: "app-tareas-a1ee5.firebaseapp.com",
  projectId: "app-tareas-a1ee5",
  storageBucket: "app-tareas-a1ee5.appspot.com",
  messagingSenderId: "378349280411",
  appId: "1:378349280411:web:945c98fc3718b5055cba3e"
};

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    provideFirebaseApp(() => initializeApp(firebaseConfig )),
    provideFirestore(() => getFirestore()),
  ],
  providers: [SharedService],
  bootstrap: [AppComponent]
})
export class AppModule { }
