import { Component } from '@angular/core';
import { SharedService } from './services/shared.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AppTareas';

  constructor(private services:SharedService){}

notes:any=[];

  listNotes (){

    this.services.getNotes().subscribe((res)=>{
      this.notes = res;
    })
  }

  ngOnInit(){
    this.listNotes
  }

  addNotes(newNote: string){
    this.services.addNotes(newNote).then((res)=>{
      console.log(res);
      this.listNotes();
    })

  }

 deleteNotes(id: string){
    this.services.deleteNotes(id).then((res)=>{
      this.listNotes();
    })
    
  }

  }





